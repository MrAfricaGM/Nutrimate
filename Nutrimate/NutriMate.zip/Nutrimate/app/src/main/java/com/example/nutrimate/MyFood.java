package com.example.nutrimate;

public class MyFood {
    static int[] imageF = {
            R.drawable.indomie_kaldu_ayam, R.drawable.chitato_sapi_panggang,
            R.drawable.goodtime_double_choc
    };

    static String[] nameF = {
            "Indomie Kaldu Ayam", "Chitato Rasa Sapi Panggang",
            "GoodTime Double Choc"
    };
}
