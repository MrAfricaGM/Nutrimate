package com.example.nutrimate;

public class MyBeverage {
    static int[] imageB = {
            R.drawable.ultramilk_coklat_200ml, R.drawable.cocacola_390ml, R.drawable.tehkotak_200ml
    };

    static String[] nameB = {
            "Ultra Milk Rasa Coklat (200ml)", "Coca Cola (390ml)", "Teh Kotak (200ml)"
    };
}
