package com.example.nutrimate;

public class CalculateActivity {
}
