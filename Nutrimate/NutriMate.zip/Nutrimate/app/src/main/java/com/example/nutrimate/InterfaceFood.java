package com.example.nutrimate;public interface InterfaceFood {
}
